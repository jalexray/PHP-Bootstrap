<?php
	include ("header.php");
?>
<div class="container-fluid">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
			<h2>Welcome to PHP and Bootstrap!</h2>
			<p>To get started, edit index.php</p>
			<h4>Press Cmd+R to reload.</h4>
			<p>Want to run this page locally? I recommend MAMP.</p>
			<h4 style="color:#4EC7E9">Questions? Tweet at me - <a href="http://www.twitter.com/alexraytweets">@AlexRayTweets</a></h4>
		</div>
	</div>
</div>	